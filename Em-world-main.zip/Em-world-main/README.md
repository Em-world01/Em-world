# Em-world
A personal corner of ideas, tech notes,digital musings and a bit of elegant mischief.
